//#region src/utils/debug.ts
var e = () => {}, t = {
	log: e,
	warn: e,
	error: e
};
//#endregion
//#region src/extension/bridgeUtils.ts
function n(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function r(e, t) {
	if (typeof e == "function") try {
		e(t);
	} catch {}
}
//#endregion
//#region src/extension/webext.ts
var i = globalThis.browser, a = globalThis.chrome, o = i ?? a ?? null, s = !!i && o === i, c = typeof i?.runtime?.getBrowserInfo == "function", l = c;
function u() {
	let e = a?.runtime?.lastError ?? o?.runtime?.lastError;
	return e?.message ? String(e.message) : null;
}
async function d(e, t = [], n = {}) {
	if (typeof e != "function") throw TypeError("WebExtension API is not available");
	let r = n.mapCbArgs, i = n.rejectOnLastError !== !1;
	return s ? await e(...t) : await new Promise((n, a) => {
		try {
			e(...t, (...e) => {
				let t = i ? u() : null;
				t ? a(Error(t)) : n(r ? r(...e) : e[0]);
			});
		} catch (e) {
			a(e);
		}
	});
}
async function f(e) {
	let t = c ? void 0 : a?.storage?.local;
	if (t && typeof t.get == "function") return await new Promise((n, r) => {
		try {
			t.get(e, (e) => {
				let t = u();
				if (t) {
					r(Error(t));
					return;
				}
				n(e);
			});
		} catch (e) {
			r(e);
		}
	});
	let n = i?.storage?.local ?? o?.storage?.local;
	return await d(n?.get?.bind(n), [e]);
}
async function p(e) {
	let t = c ? void 0 : a?.storage?.local;
	if (t && typeof t.set == "function") {
		await new Promise((n, r) => {
			try {
				t.set(e, () => {
					let e = u();
					if (e) {
						r(Error(e));
						return;
					}
					n();
				});
			} catch (e) {
				r(e);
			}
		});
		return;
	}
	let n = i?.storage?.local ?? o?.storage?.local;
	await d(n?.set?.bind(n), [e], { mapCbArgs: () => void 0 });
}
async function m(e) {
	let t = c ? void 0 : a?.storage?.local;
	if (t && typeof t.remove == "function") {
		await new Promise((n, r) => {
			try {
				t.remove(e, () => {
					let e = u();
					if (e) {
						r(Error(e));
						return;
					}
					n();
				});
			} catch (e) {
				r(e);
			}
		});
		return;
	}
	let n = i?.storage?.local ?? o?.storage?.local;
	await d(n?.remove?.bind(n), [e], { mapCbArgs: () => void 0 });
}
async function h(e, t) {
	let n = o?.notifications, r = n?.create;
	!n || typeof r != "function" || await d(r.bind(n), [e, t], { mapCbArgs: () => void 0 });
}
async function g(e) {
	let t = o?.notifications, n = t?.clear;
	!t || typeof n != "function" || await d(n.bind(t), [e], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
async function _(e, t) {
	let n = o?.windows, r = n?.update;
	!n || typeof r != "function" || await d(r.bind(n), [e, t], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
async function v(e, t) {
	let n = o?.tabs, r = n?.update;
	!n || typeof r != "function" || await d(r.bind(n), [e, t], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
//#endregion
//#region src/extension/backgroundNotifications.ts
function y(e) {
	return !e || typeof e != "object" ? !1 : e.type === "gm_notification";
}
function b(e) {
	let t = e && typeof e == "object" ? e : {}, n = Number(t.timeout ?? 0);
	return {
		title: t.title == null ? "" : String(t.title),
		text: t.text == null ? "" : String(t.text),
		silent: !!t.silent,
		timeout: Number.isFinite(n) && n > 0 ? n : 0
	};
}
function x(e) {
	let t = e.tab?.id, n = e.tab?.windowId;
	return `vot:${typeof t == "number" ? t : -1}:${typeof n == "number" ? n : -1}:${typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}:${Math.random().toString(36).slice(2)}`}`;
}
function S(e) {
	let t = typeof o?.runtime?.getBrowserInfo == "function", n = {
		type: "basic",
		iconUrl: o?.runtime?.getURL ? o.runtime.getURL("icons/icon-128.png") : "icons/icon-128.png",
		title: e.title || "VOT",
		message: e.text
	};
	return t || (n.silent = e.silent), n;
}
function C() {
	o?.runtime?.onMessage?.addListener?.((e, i, a) => {
		if (!y(e)) return;
		let o = b(e.details), s = x(i), c = S(o);
		return (async () => {
			try {
				await h(s, c), o.timeout > 0 && setTimeout(() => {
					g(s);
				}, o.timeout), r(a, { ok: !0 });
			} catch (e) {
				t.error("[VOT EXT][background] Failed to create notification", e), r(a, {
					ok: !1,
					error: n(e)
				});
			}
		})(), !0;
	}), o?.notifications?.onClicked?.addListener?.((e) => {
		if (!e.startsWith("vot:")) return;
		let t = e.split(":");
		if (t.length < 3) return;
		let n = Number(t[1]), r = Number(t[2]);
		Number.isFinite(r) && r >= 0 && _(r, { focused: !0 }), Number.isFinite(n) && n >= 0 && v(n, { active: !0 });
	});
}
//#endregion
//#region src/extension/backgroundStorage.ts
function w(e) {
	return !e || typeof e != "object" ? !1 : e.type === "gm_storage";
}
function T(e) {
	switch (typeof e) {
		case "string": return e;
		case "number":
		case "boolean":
		case "bigint": return String(e);
		default: return "";
	}
}
async function E(e, t) {
	switch (e) {
		case "gm_getValue": {
			let e = T(t?.key), n = t?.def, r = await f(e);
			return Object.hasOwn(r, e) ? r[e] : n;
		}
		case "gm_setValue": return await p({ [T(t?.key)]: t?.value }), !0;
		case "gm_deleteValue": return await m(T(t?.key)), !0;
		case "gm_listValues": {
			let e = await f(null);
			return Object.keys(e ?? {});
		}
		case "gm_getValues": return await f(t?.defaults ?? {});
		default: throw Error(`Unknown storage action: ${e}`);
	}
}
function D() {
	o?.runtime?.onMessage?.addListener?.((e, t, i) => {
		if (w(e)) return (async () => {
			try {
				r(i, {
					ok: !0,
					result: await E(String(e.action ?? ""), e.payload)
				});
			} catch (e) {
				r(i, {
					ok: !1,
					error: n(e)
				});
			}
		})(), !0;
	});
}
//#endregion
//#region src/extension/bodySerialization.ts
var O = typeof Uint8Array.prototype.toBase64 == "function" ? Uint8Array.prototype.toBase64 : null, k = Uint8Array.fromBase64, ee = /[-_]/;
function te(e) {
	let t = String(e).replaceAll(/\s+/g, ""), n = t.length % 4;
	if (n === 1) throw TypeError("Invalid base64 input.");
	return n === 0 ? t : t + "=".repeat(4 - n);
}
function ne(e) {
	let t = "";
	for (let n of e) t += String.fromCharCode(n);
	return t;
}
function A(e) {
	if (typeof O == "function") return O.call(e);
	let t = globalThis.btoa;
	if (typeof t != "function") throw TypeError("Base64 encoder is not available in this environment.");
	return t(ne(e));
}
function re(e) {
	return A(new Uint8Array(e));
}
function j(e) {
	let t = te(e), n = t.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof k == "function") {
		let e = ee.test(t);
		return k(e ? n : t, e ? { alphabet: "base64" } : void 0);
	}
	let r = globalThis.atob;
	if (typeof r != "function") throw TypeError("Base64 decoder is not available in this environment.");
	let i = r(n), a = new Uint8Array(i.length);
	for (let e = 0; e < i.length; e += 1) a[e] = i.charCodeAt(e);
	return a;
}
var M = 1e7, ie = 12, ae = 2;
function N(e) {
	return typeof e == "object" && !!e;
}
function oe(e) {
	return P(e) === "[object Object]";
}
function P(e) {
	try {
		return Object.prototype.toString.call(e);
	} catch {
		return null;
	}
}
function F(e) {
	return P(e) === "[object ArrayBuffer]";
}
function se(e) {
	try {
		let t = e?.constructor?.name;
		return typeof t == "string" ? t : null;
	} catch {
		return null;
	}
}
function I(e, t) {
	try {
		let n = e?.[t];
		return typeof n == "string" ? n : null;
	} catch {
		return null;
	}
}
function L(e) {
	if (P(e) === "[object Blob]") return !0;
	if (!e || typeof e != "object") return !1;
	try {
		let t = e, n = typeof t.arrayBuffer == "function", r = typeof t.slice == "function", i = typeof t.size == "number", a = typeof t.type == "string";
		return (n || r) && i && a;
	} catch {
		return !1;
	}
}
function ce(e) {
	try {
		return JSON.stringify(e);
	} catch {
		return null;
	}
}
function R(e) {
	if (typeof e != "number" || !Number.isFinite(e)) return null;
	let t = Math.trunc(e);
	return t < 0 || t > M ? null : t;
}
function z(e) {
	return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function B(e) {
	let t = e.length;
	if (t > M) return null;
	let n = new Uint8Array(t);
	for (let r = 0; r < t; r += 1) {
		let t = z(e[r]);
		if (t === null) return null;
		n[r] = t;
	}
	return n;
}
function V(e) {
	return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
}
function le(e) {
	return V(e).slice();
}
function ue(e) {
	if (e === "") return null;
	let t = Number(e);
	return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function H(e) {
	if (!N(e)) return !1;
	let t = e;
	return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function U(e, t = 0) {
	if (t > ae || !N(e)) return null;
	let n = e;
	if (F(e)) return new Uint8Array(e);
	try {
		if (ArrayBuffer.isView(e)) return le(e);
	} catch {}
	return Array.isArray(e) ? B(e) : de(n) || fe(n) || pe(n, e, t) || me(n) || (oe(e) ? he(n) : null);
}
function de(e) {
	let t = [
		e.type === "Buffer" && Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.bytes) ? e.bytes : null
	];
	for (let e of t) {
		if (!e) continue;
		let t = B(e);
		if (t) return t;
	}
	return null;
}
function fe(e) {
	let t = [e.b64, e.base64];
	for (let e of t) if (typeof e == "string") try {
		return j(e);
	} catch {}
	return null;
}
function pe(e, t, n) {
	let r = R(e.byteLength), i = R(e.byteOffset ?? 0);
	if (r === null || i === null) return null;
	let a = e.buffer;
	if (F(a)) try {
		return new Uint8Array(a, i, r).slice();
	} catch {}
	if (!a || a === t) return null;
	let o = U(a, n + 1);
	if (!o || i > o.byteLength) return null;
	let s = Math.min(o.byteLength, i + r);
	return o.slice(i, s);
}
function me(e) {
	let t = R(e.length);
	if (t === null) return null;
	let n = e, r = new Uint8Array(t);
	for (let e = 0; e < t; e += 1) {
		let t = z(n[e]);
		if (t === null) return null;
		r[e] = t;
	}
	return r;
}
function he(e) {
	let t = Object.keys(e);
	if (!t.length) return null;
	let n = Array(t.length), r = -1;
	for (let e = 0; e < t.length; e += 1) {
		let i = ue(t[e]);
		if (i === null || i > M) return null;
		n[e] = i, i > r && (r = i);
	}
	let i = new Uint8Array(r + 1);
	for (let r = 0; r < t.length; r += 1) {
		let a = z(e[t[r]]);
		if (a === null) return null;
		i[n[r]] = a;
	}
	return i;
}
function W(e) {
	let t = e === null ? "null" : typeof e, n = P(e), r = se(e), i = ge(e, t, n, r);
	if (i) return i;
	let a = _e(e, t, n, r);
	if (a) return a;
	let o = ve(e, t, n, r);
	if (o) return o;
	let s = U(e);
	if (s) return {
		kind: "coerced-bytes",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: s.byteLength
	};
	if (N(e)) {
		let i = Object.keys(e);
		return {
			kind: "object",
			jsType: t,
			tag: n,
			ctor: r,
			keyCount: i.length,
			keys: i.slice(0, ie)
		};
	}
	return {
		kind: "primitive",
		jsType: t,
		tag: n,
		ctor: r
	};
}
function ge(e, t, n, r) {
	return e == null ? {
		kind: "empty",
		jsType: t,
		tag: n,
		ctor: r
	} : typeof e == "string" ? {
		kind: "string",
		jsType: t,
		tag: n,
		ctor: r,
		textLength: e.length
	} : null;
}
function _e(e, t, n, r) {
	return H(e) ? {
		kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
		jsType: t,
		tag: n,
		ctor: r,
		base64Length: e.b64.length,
		mime: I(e, "mime")
	} : null;
}
function ve(e, t, n, r) {
	if (F(e)) return {
		kind: "ArrayBuffer",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: e.byteLength
	};
	try {
		if (ArrayBuffer.isView(e)) return {
			kind: r ? `TypedArray:${r}` : "TypedArray",
			jsType: t,
			tag: n,
			ctor: r,
			byteLength: e.byteLength
		};
	} catch {}
	return L(e) ? {
		kind: "BlobLike",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: typeof e.size == "number" ? Number(e.size) : -1,
		mime: I(e, "type")
	} : null;
}
function ye(e) {
	if (e == null) return;
	if (typeof e == "string" || F(e)) return e;
	try {
		if (ArrayBuffer.isView(e)) return V(e);
	} catch {}
	if (L(e)) return e;
	if (H(e)) return be(e);
	let t = U(e);
	if (t) return t;
	if (N(e)) {
		let t = ce(e);
		if (typeof t == "string") return t;
	}
	return String(e);
}
function be(e) {
	let t = j(e.b64);
	if ((typeof e.kind == "string" && e.kind ? e.kind : "bytes") !== "blob") return t;
	let n = e.mime, r = t.buffer;
	return typeof n == "string" && n ? new Blob([r], { type: n }) : new Blob([r]);
}
//#endregion
//#region src/extension/yandexHeaders.ts
var xe = "api.browser.yandex.ru", Se = new Set([
	"sec-ch-ua",
	"sec-ch-ua-mobile",
	"sec-ch-ua-platform",
	"sec-ch-ua-full-version-list"
]), G = [
	"sec-ch-ua-full-version",
	"sec-ch-ua-platform-version",
	"sec-ch-ua-arch",
	"sec-ch-ua-bitness",
	"sec-ch-ua-model",
	"sec-ch-ua-wow64"
], Ce = new Set(G);
function we(e) {
	return String(e || "") === xe;
}
function K(e) {
	return String(e || "").trim();
}
function Te(e) {
	let t = K(e).toLowerCase();
	return t ? !!(t === "origin" || t === "referer" || Ce.has(t) || t.startsWith("sec-ch-ua") && !Se.has(t)) : !1;
}
function Ee(e) {
	let t = {};
	for (let [n, r] of Object.entries(e || {})) {
		let e = K(n);
		e && (Te(e) || (t[e] = String(r)));
	}
	return t;
}
//#endregion
//#region src/extension/background.ts
var De = 512 * 1024, Oe = /application\/(?:x-)?protobuf|application\/octet-stream/, ke = /^(?=.*[+/=_-])[A-Za-z0-9+/=_-]+$/, q = 9001, J = 9002, Ae = 9003, Y = /* @__PURE__ */ new Map(), X = Promise.resolve();
function Z() {
	return !!o?.declarativeNetRequest?.updateSessionRules;
}
function je(e) {
	let t = o?.declarativeNetRequest?.updateSessionRules;
	if (typeof t != "function") return Promise.resolve();
	try {
		let n = t({
			addRules: e.addRules || [],
			removeRuleIds: e.removeRuleIds || []
		});
		if (n && typeof n.then == "function") return n;
	} catch {}
	return new Promise((n, r) => {
		try {
			t({
				addRules: e.addRules || [],
				removeRuleIds: e.removeRuleIds || []
			}, () => {
				let e = u();
				e ? r(Error(e)) : n();
			});
		} catch (e) {
			r(e);
		}
	});
}
function Me(e) {
	let t = K(e).toLowerCase();
	if (!t) return !1;
	switch (t[0]) {
		case "s": return t.startsWith("sec-");
		case "p": return t.startsWith("proxy-");
		case "u": return t === "user-agent";
		case "o": return t === "origin";
		case "r": return t === "referer";
		default: return !1;
	}
}
function Q(e) {
	let t = e.map((e) => [`${K(String(e.header)).toLowerCase()}:${String(e.operation)}`, String("value" in e ? e.value : "")]).sort((e, t) => e[0].localeCompare(t[0]));
	return JSON.stringify(t);
}
function $(e, t, n) {
	return t === Y.get(e) ? Promise.resolve() : (X = X.catch(() => void 0).then(async () => {
		t !== Y.get(e) && (await je({
			removeRuleIds: [e],
			addRules: [n]
		}), Y.set(e, t));
	}), X);
}
async function Ne(e, t) {
	if (!Z()) return;
	let n = "";
	try {
		n = new URL(e).hostname;
	} catch {
		return;
	}
	if (!we(n)) return;
	let r = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "Referer",
			operation: "remove"
		},
		...G.map((e) => ({
			header: e,
			operation: "remove"
		}))
	], i = Ee(t);
	for (let [e, t] of Object.entries(i)) r.push({
		header: K(e),
		operation: "set",
		value: String(t)
	});
	await $(q, Q(r), {
		id: q,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: r
		},
		condition: {
			urlFilter: "|https://api.browser.yandex.ru/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function Pe(e) {
	try {
		let t = new URL(e);
		return t.protocol === "https:" && t.hostname === "www.youtube.com" && t.pathname.startsWith("/youtubei/");
	} catch {
		return !1;
	}
}
function Fe(e) {
	try {
		let t = new URL(e), n = t.hostname.toLowerCase();
		return t.protocol === "https:" && (n === "googlevideo.com" || n.endsWith(".googlevideo.com"));
	} catch {
		return !1;
	}
}
async function Ie(e) {
	if (!Z() || !Pe(e)) return;
	let t = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "x-client-data",
			operation: "remove"
		},
		{
			header: "x-goog-visitor-id",
			operation: "remove"
		}
	];
	await $(J, JSON.stringify({
		v: 2,
		headers: Q(t)
	}), {
		id: J,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: t
		},
		condition: {
			urlFilter: "|https://www.youtube.com/youtubei/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
async function Le(e) {
	if (!Z() || !Fe(e)) return;
	let t = [{
		header: "x-client-data",
		operation: "remove"
	}];
	await $(Ae, JSON.stringify({
		v: 1,
		headers: Q(t)
	}), {
		id: Ae,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: t
		},
		condition: {
			urlFilter: "||googlevideo.com/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function Re(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function ze(e) {
	return Array.from(e.entries()).map(([e, t]) => `${e}: ${t}`).join("\r\n");
}
function Be(e) {
	let t = {};
	if (!e) return t;
	for (let [n, r] of Object.entries(e)) r !== void 0 && (typeof r == "string" || typeof r == "number" || typeof r == "boolean") && (t[String(n)] = String(r));
	return t;
}
function Ve(e, t) {
	return {
		finalUrl: e,
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error: t
	};
}
function He(e) {
	let t = new Uint8Array(e.byteLength);
	return t.set(e), t.buffer;
}
function Ue(e) {
	return l ? { chunk: He(e) } : { chunkB64: A(e) };
}
function We(e) {
	return l ? { response: e } : e.byteLength <= 0 ? {} : { responseB64: re(e) };
}
function Ge(e, t) {
	let n = t.toLowerCase();
	for (let [t, r] of Object.entries(e)) if (String(t).toLowerCase() === n) return String(r);
}
function Ke(e) {
	return Oe.test(String(e ?? "").toLowerCase());
}
function qe(e) {
	let t = String(e ?? "");
	if (!ke.test(t)) return null;
	let n = t.replaceAll("-", "+").replaceAll("_", "/"), r = n.length % 4;
	if (r === 1) return null;
	let i = r === 0 ? n : `${n}${"=".repeat(4 - r)}`;
	try {
		return j(i);
	} catch {
		return null;
	}
}
function Je(e) {
	let t = String(e || ""), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = (t.codePointAt(e) ?? 0) & 255;
	return n;
}
function Ye(e) {
	return /^\[object [^\]]+\]$/.test(String(e || "").trim());
}
var Xe = 0;
o?.runtime?.onConnect?.addListener?.((e) => {
	if (!e || typeof e != "object") return;
	let n = e;
	if (n.name !== "vot_gm_xhr" || typeof n.onDisconnect?.addListener != "function" || typeof n.onMessage?.addListener != "function" || typeof n.postMessage != "function") return;
	let r = (e) => {
		n.postMessage?.(e);
	};
	Xe += 1;
	let i = Xe, a = null, o = null, s = !1, c = !1, l = () => {
		o !== null && (clearTimeout(o), o = null);
	};
	n.onDisconnect.addListener(() => {
		l(), t.warn("[VOT EXT][background][xhr] port disconnected", { xhrSessionId: i }), u();
	});
	let u = () => {
		try {
			a?.abort();
		} catch {}
	}, d = () => {
		s = !0, t.warn("[VOT EXT][background][xhr] abort requested", { xhrSessionId: i }), u();
	}, f = (e) => {
		let t = Be(e.headers), n = {}, r = {};
		for (let [e, i] of Object.entries(t)) Me(e) ? r[e] = i : n[e] = i;
		return {
			allHeaders: t,
			headers: n,
			forbiddenHeaders: r
		};
	}, p = (e) => {
		let t = {
			finalUrl: e,
			readyState: 4,
			status: 0,
			statusText: "",
			responseHeaders: "",
			response: null,
			responseText: "",
			error: "Aborted"
		};
		try {
			r({
				type: "abort",
				state: "terminal",
				error: t
			});
		} catch {}
	}, m = (e) => e.anonymous || e.withCredentials === !1 ? "omit" : "include", h = (e) => {
		if (e.nocache) return "no-store";
		if (e.revalidate) return "no-cache";
	}, g = (e, n, r, a) => {
		if (n === "GET") return;
		let o = ye(e.data), s, c = () => (s === void 0 && (s = U(e.data)), s), l = Ge(r, "content-type"), u = Ke(l);
		if (t.log("[VOT EXT][background][xhr] body decoded", {
			xhrSessionId: i,
			url: a,
			method: n,
			contentType: l ?? null,
			isProtobufRequest: u,
			sourceBody: W(e.data),
			decodedBody: W(o)
		}), u && o == null) {
			let e = c();
			e && (o = e, t.warn("[VOT EXT][background][xhr] protobuf body recovered from raw payload", {
				xhrSessionId: i,
				url: a,
				method: n,
				recoveredBody: W(o)
			}));
		}
		if (typeof o == "string" && u) {
			if (Ye(o)) {
				let r = c();
				r && (o = r, t.warn("[VOT EXT][background][xhr] recovered protobuf body from object-like string fallback", {
					xhrSessionId: i,
					url: a,
					method: n,
					sourceBody: W(e.data),
					recoveredBody: W(r)
				}));
			}
			if (typeof o == "string") {
				let e = qe(o);
				o = e ?? Je(o), t.log("[VOT EXT][background][xhr] protobuf string converted to bytes", {
					xhrSessionId: i,
					url: a,
					method: n,
					strategy: e ? "base64" : "latin1",
					convertedBody: W(o)
				});
			}
		}
		return o;
	}, _ = (e) => {
		let t = {
			method: e.method,
			headers: e.headers,
			redirect: e.redirect,
			credentials: e.credentials,
			signal: a?.signal
		};
		return e.body !== void 0 && (t.body = e.body), e.cache !== void 0 && (t.cache = e.cache), t;
	}, v = async (e) => {
		let { url: n, method: a, responseType: o, res: s } = e;
		t.log("[VOT EXT][background][xhr] fetch response received", {
			xhrSessionId: i,
			url: s.url || n,
			method: a,
			status: s.status,
			statusText: s.statusText,
			responseType: o,
			contentType: s.headers.get("content-type") || null,
			contentLength: s.headers.get("content-length") || null
		});
		let c = ze(s.headers), u = s.url || n, d = s.headers.get("content-type") || "", f = (e) => ({
			finalUrl: u,
			readyState: e,
			status: s.status,
			statusText: s.statusText,
			responseHeaders: c
		}), p = o === "arraybuffer" || o === "blob" || o === "stream", m, h, g;
		if (p) {
			let e = Number(s.headers.get("content-length") || 0);
			if (s.body && (!Number.isFinite(e) || e > De)) {
				let t = 0, n = Number.isFinite(e) ? e : 0, i = s.body.getReader();
				for (;;) {
					let { done: e, value: a } = await i.read();
					if (e) break;
					a && (t += a.byteLength, r({
						type: "progress",
						state: "in_flight",
						progress: {
							...f(3),
							loaded: t,
							total: n,
							lengthComputable: n > 0,
							...Ue(a)
						}
					}));
				}
			} else {
				let e = We(await s.arrayBuffer());
				m = e.response, g = e.responseB64;
			}
		} else if (o === "json") {
			h = await s.text();
			try {
				m = JSON.parse(h);
			} catch {
				m = null;
			}
		} else h = await s.text(), m = h;
		l(), t.log("[VOT EXT][background][xhr] terminal", {
			xhrSessionId: i,
			state: "terminal",
			kind: "load",
			url: u,
			status: s.status,
			responseType: o,
			responseBody: W(m),
			responseTextLength: h?.length ?? 0,
			responseB64Length: g?.length ?? 0
		}), r({
			type: "load",
			state: "terminal",
			response: {
				...f(4),
				responseType: o,
				...d ? { contentType: d } : {},
				...g ? { responseB64: g } : {},
				response: m,
				...typeof h == "string" ? { responseText: h } : {}
			}
		});
	}, y = (e, n, a, o) => {
		if (l(), s || c || o instanceof DOMException && o.name === "AbortError") {
			let o = c ? "timeout" : "abort", s = Ve(e, o === "timeout" ? "Timeout" : "Aborted");
			try {
				r({
					type: o,
					state: "terminal",
					error: s
				});
			} catch {}
			t.warn("[VOT EXT][background][xhr] terminal", {
				xhrSessionId: i,
				state: "terminal",
				kind: o,
				url: e,
				method: n,
				responseType: a
			});
			return;
		}
		let u = Ve(e, Re(o));
		r({
			type: "error",
			state: "terminal",
			error: u
		}), t.error("[VOT EXT][background][xhr] terminal", {
			xhrSessionId: i,
			state: "terminal",
			kind: "error",
			url: e,
			method: n,
			responseType: a,
			error: u.error
		});
	}, b = async (e) => {
		let n = s && a === null;
		s = !1;
		let { details: r } = e, l = r.url, d = (r.method || "GET").toUpperCase(), { allHeaders: b, headers: x, forbiddenHeaders: S } = f(r), C = Number(r.timeout || 0), w = String(r.responseType || "text").toLowerCase();
		if (t.log("[VOT EXT][background][xhr] start", {
			xhrSessionId: i,
			state: "in_flight",
			url: l,
			method: d,
			responseType: w,
			timeoutMs: C,
			headerCount: Object.keys(b).length,
			headerNames: Object.keys(b),
			forbiddenHeaderNames: Object.keys(S),
			body: W(r.data)
		}), n) {
			p(l);
			return;
		}
		c = !1, a = new AbortController(), C > 0 && (o = setTimeout(() => {
			c = !0, u();
		}, C));
		let T = m(r), E = h(r), D = r.redirect === "error" || r.redirect === "manual" ? r.redirect : "follow";
		try {
			try {
				await Le(l), await Ie(l), await Ne(l, S);
			} catch (e) {
				console.warn("[VOT Extension] Failed to apply DNR header rules; requests may break:", e);
			}
			let e = g(r, d, b, l);
			t.log("[VOT EXT][background][xhr] fetch dispatch", {
				xhrSessionId: i,
				url: l,
				method: d,
				credentials: T,
				redirect: D,
				cache: E ?? "default",
				body: W(e)
			});
			let n = _({
				method: d,
				headers: x,
				redirect: D,
				credentials: T,
				body: e,
				cache: E
			});
			await v({
				url: l,
				method: d,
				responseType: w,
				res: await fetch(l, n)
			});
		} catch (e) {
			y(l, d, w, e);
		}
	};
	n.onMessage.addListener(async (e) => {
		if (!(!e || typeof e != "object")) {
			if (e.type === "abort") {
				d();
				return;
			}
			e.type === "start" && await b(e);
		}
	});
}), D(), C();
//#endregion
